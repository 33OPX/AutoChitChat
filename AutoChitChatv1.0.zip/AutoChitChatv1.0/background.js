// Background script (optional)
chrome.runtime.onInstalled.addListener(() => {
  console.log("Chat Automation Extension installed.");
});